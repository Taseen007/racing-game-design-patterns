package strategy;

public class AlpineTurbo implements TurboBehavior {

    public void turbo(){
        System.out.println("Turbo: Alpine");
    }
}