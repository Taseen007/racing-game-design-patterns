package strategy;

public class CumminsTurbo implements TurboBehavior {

    public void turbo(){
        System.out.println("Turbo: Cummins");
    }
}