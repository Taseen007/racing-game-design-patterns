package strategy;

public class HoneywellTurbo implements TurboBehavior {

    public void turbo(){
        System.out.println("Turbo: Honeywell");
    }
}