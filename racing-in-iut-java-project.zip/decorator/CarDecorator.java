package decorator;

import car.Car;

public abstract class CarDecorator extends Car {

    protected Car car;

    public CarDecorator(Car car){
        this.car = car;
    }
}