package decorator;

import car.Car;

public class ResonacNOS extends CarDecorator {

    public ResonacNOS(Car car){
        super(car);
    }

    public void accelerate(){
        car.accelerate();
        System.out.println("NOS Applied: Resonac Boost");
    }

    public void carInfo(){
        car.carInfo();
    }
}