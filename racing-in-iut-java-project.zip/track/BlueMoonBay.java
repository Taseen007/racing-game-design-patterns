package track;

public class BlueMoonBay implements Track {

    public void trackInfo(){
        System.out.println("Track: Blue Moon Bay Speedway (USA)");
    }
}