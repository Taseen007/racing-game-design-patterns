package track;

public class SpaFrancorchamps implements Track {

    public void trackInfo(){
        System.out.println("Track: Circuit de Spa-Francorchamps (Germany)");
    }
}