package track;

public class BBRaceway implements Track {

    public void trackInfo(){
        System.out.println("Track: BB Raceway (Japan)");
    }
}