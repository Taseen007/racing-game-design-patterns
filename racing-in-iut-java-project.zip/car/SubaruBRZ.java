package car;

public class SubaruBRZ extends CoupeCar {

    public void carInfo(){
        super.carInfo();
        System.out.println("Model: Subaru BRZ");
    }
}