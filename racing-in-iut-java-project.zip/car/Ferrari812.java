package car;

public class Ferrari812 extends RoadsterCar {

    public void carInfo(){
        super.carInfo();
        System.out.println("Model: Ferrari 812");
    }
}