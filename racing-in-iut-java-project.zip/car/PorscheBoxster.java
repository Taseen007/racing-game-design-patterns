package car;

public class PorscheBoxster extends RoadsterCar {

    public void carInfo(){
        super.carInfo();
        System.out.println("Model: Porsche Boxster");
    }
}