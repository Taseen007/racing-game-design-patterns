package car;

public abstract class RoadsterCar extends Car {

    public void carInfo(){
        System.out.println("Car Category: Roadster");
    }
}