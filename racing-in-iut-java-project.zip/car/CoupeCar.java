package car;

public abstract class CoupeCar extends Car {

    public void carInfo(){
        System.out.println("Car Category: Coupe");
    }
}