package car;

public class ToyotaGR86 extends CoupeCar {

    public void carInfo(){
        super.carInfo();
        System.out.println("Model: Toyota GR86");
    }
}